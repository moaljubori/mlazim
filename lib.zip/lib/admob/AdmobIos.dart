// ignore_for_file: non_constant_identifier_names

// -------------------------------- HOME BANNER 1
import 'package:admob_flutter/admob_flutter.dart';

AdmobBanner B1C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/5678249816',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 1

// -------------------------------- HOME BANNER 2
AdmobBanner B2C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/6935491168',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 2

// -------------------------------- HOME BANNER 3
AdmobBanner B3C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/4546993363',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 3

// -------------------------------- HOME BANNER 4
AdmobBanner B4C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/4117756138',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 4

// -------------------------------- HOME BANNER 5
AdmobBanner B5C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/2822848154',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 5

// -------------------------------- HOME BANNER 6
AdmobBanner B6C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/4497030083',
  adSize: AdmobBannerSize.BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 6

// -------------------------------- HOME BANNER 7
AdmobBanner B7C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/9090881218',
  adSize: AdmobBannerSize.BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 7

// -------------------------------- HOME BANNER 8
AdmobBanner B8C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/3740344006',
  adSize: AdmobBannerSize.BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 8

// -------------------------------- HOME BANNER 9
AdmobBanner B9C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/4007937318',
  adSize: AdmobBannerSize.BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 9

// -------------------------------- HOME BANNER 10
AdmobBanner B10C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/5371128054',
  adSize: AdmobBannerSize.BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 10

// -------------------------------- HOME BANNER 11
AdmobBanner B11C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/7203084477',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
// -------------------------------- HOME BANNER 11

// -------------------------------- HOME BANNER 12
AdmobBanner B12C = AdmobBanner(
  adUnitId: 'ca-app-pub-8284807621779053/8735657992',
  adSize: AdmobBannerSize.LARGE_BANNER,
  listener: (AdmobAdEvent event, Map<String, dynamic>? args) {},
  onBannerCreated: (AdmobBannerController controller) {},
);
  // -------------------------------- HOME BANNER 12
   


 