//Categories SetState Managemnt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
// ignore_for_file: file_names, non_constant_identifier_names
import 'package:flutter/material.dart';



// late ValueChanged<int> SetState_Classroom;
late ValueChanged<int> SetState_Subjects_Show_Classroom;
late ValueChanged<int> SetState_Select_Subjects_Classroom;
late ValueChanged<int> SetState_Request_sheet;
late ValueChanged<int> SetState_HomePage;
late ValueChanged<int> PageSerachSetState;
late ValueChanged<int> favouritesSetState;
double sizeadstest =  130; 