// ignore_for_file: non_constant_identifier_names, file_names


GetNumberViewGrid(index){
 
 if (100.0 <= index && index <= 200.0) {
 return [ 1, (2 / 3.6)];
 }  

 if (200.0 <= index && index <= 300.0) {
  return [ 2, (2 / 5)];
 }  

 if (300.0 <= index && index <= 400.0) {
 return [ 2, (2 / 3.5)];
 }  

  if (400.0 <= index && index <= 500.0) {
 return [ 2, (2 / 3.2)];
 } 

  if (500.0 <= index && index <= 580.0) {
 return [ 3, (2 / 3.5)];
 }  

   if (580.0 <= index && index <= 650.0) {
 return [ 4, (2 / 3.8)];
 }  



 if (650.0 <= index && index <= 850.0) {
 return [ 4, (2 / 3.8)];
 }  

  if (850.0 <= index && index <= 1050.0) {
 return [ 5, (2 / 3.5)];
 }  

   if (1050.0 <= index && index <= 1250.0) {
  return [ 6, (2 / 3.5)];
 }  


   if (1250.0 <= index && index <= 1600.0) {
 return [ 7, (2 / 3.5)];
 }  
   if (1600.0 <= index && index <= 1800.0) {
 return [ 8, (2 / 3.5)];
 }  
   if (1800.0 <= index && index <= 1900.0) {
 return [ 9, (2 / 3.5)];
 }  
}


 

GetNumberViewGridBook(index){
 
 if (100.0 <= index && index <= 200.0) {
 return [ 1, (2 / 4.8)];
 }  

 if (200.0 <= index && index <= 300.0) {
  return [ 1, (2 / 4.8)];
 }  


 if (300.0 <= index && index <= 350.0) {
 return [ 2, (2 / 6)];
 }  

 if (350.0 <= index && index <= 400.0) {
 return [ 2, (2 / 5)];
 }  

  if (400.0 <= index && index <= 450.0) {
 return [ 2, (2 / 4.2)];
 } 

  if (450.0 <= index && index <= 580.0) {
 return [ 2, (2 / 3.6)];
 }  

   if (580.0 <= index && index <= 650.0) {
 return [ 2, (2 /3)];
 }  


 if (650.0 <= index && index <= 750.0) {
return [ 3, (2 /3.9)];
 }  


 if (750.0 <= index && index <= 850.0) {
return [ 3, (2 /3.5)];
 }  

  if (850.0 <= index && index <= 1050.0) {
return [ 4, (2 /3.8)];
 }  

   if (1050.0 <= index && index <= 1250.0) {
  return [ 5, (2 / 4.0)];
 }  


   if (1250.0 <= index && index <= 1600.0) {
 return [ 6, (2 / 4.2)];
 }  
   if (1600.0 <= index && index <= 1800.0) {
 return [ 8, (2 / 4.5)];
 }  
   if (1800.0 <= index && index <= 1900.0) {
 return [ 9, (2 / 3.5)];
 }  
}


 